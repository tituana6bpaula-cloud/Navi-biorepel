BLOG - PAULA DANIELA TITUAÑA GUAMÁN

Archivo principal:
index.html

El sitio ya contiene:
- Portada con los datos solicitados.
- Menú superior con Presentación, Investigación, Materiales, Evidencias, Producto, Opinión, Conclusiones y Fuentes.
- Las secciones están preparadas sin información adicional, para que puedan llenarse después.

Para tener un enlace público, el archivo debe publicarse en un servicio de hosting (por ejemplo, GitHub Pages, Google Sites o Canva Websites). El archivo index.html está listo para subir.
